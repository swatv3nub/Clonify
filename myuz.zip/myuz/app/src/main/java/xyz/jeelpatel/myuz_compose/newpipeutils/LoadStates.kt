package xyz.jeelpatel.myuz_compose.newpipeutils

enum class LoadStates{
    LOADING,
    SUCCESS,
    ERROR,
    UNINIT
}